# Shared / Icons

## Purpose

Small interface icons, seals, and symbolic navigation marks.

## Public Path

```text
/assets/img/shared/icons/
```

## Planned Assets

- `icon-moons.svg`
- `icon-frequency.svg`
- `icon-artifacts.svg`
- `icon-caravan.svg`
- `icon-ledger.svg`
- `icon-oracle.svg`

## Rules

- Prefer SVG for simple symbols and UI icons.
- Keep viewBox sizing consistent.
- Do not use full cinematic images as icons.

## Naming Standard

Use lowercase kebab-case:

```text
section-purpose-variant.webp
```

Examples:

```text
home-gate-13-moons.webp
home-gate-13-moons-mobile.webp
home-gate-13-moons-poster.webp
```

## Export Standard

- Primary photographic or cinematic format: `.webp`
- Interface symbols and simple line art: `.svg`
- Transparent raster assets when necessary: `.png`
- Keep source or editable project files outside the public `docs/assets/` directory.
- Add `width` and `height` attributes in HTML to reduce layout shift.
- Use meaningful `alt` text when the image communicates content.
- Use empty `alt=""` when the image is purely decorative.

## Status Tracking

Mark each asset as it is completed:

- [ ] Concept approved
- [ ] Image generated or photographed
- [ ] Cropped for desktop
- [ ] Cropped for mobile
- [ ] Converted to WebP
- [ ] Compressed
- [ ] Added to HTML/CSS
- [ ] Verified on mobile
- [ ] Verified on desktop
