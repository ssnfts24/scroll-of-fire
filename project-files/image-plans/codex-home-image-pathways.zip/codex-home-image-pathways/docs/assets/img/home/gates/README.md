# Home / Gates

## Purpose

Major visual entrances into the core Codex systems.

## Public Path

```text
/assets/img/home/gates/
```

## Planned Assets

- `home-gate-13-moons.webp`
- `home-gate-covenant-caravan.webp`
- `home-gate-frequency-governance.webp`
- `home-gate-witness-ledger.webp`
- `home-gate-artifact-registry.webp`
- `home-gate-genesis-oracle.webp`
- `home-gate-theory-canon.webp`

## Rules

- Each image represents one destination or system.
- Use one dominant symbol or scene per image.
- Do not combine multiple gate images into a collage.

## Naming Standard

Use lowercase kebab-case:

```text
section-purpose-variant.webp
```

Examples:

```text
home-gate-13-moons.webp
home-gate-13-moons-mobile.webp
home-gate-13-moons-poster.webp
```

## Export Standard

- Primary photographic or cinematic format: `.webp`
- Interface symbols and simple line art: `.svg`
- Transparent raster assets when necessary: `.png`
- Keep source or editable project files outside the public `docs/assets/` directory.
- Add `width` and `height` attributes in HTML to reduce layout shift.
- Use meaningful `alt` text when the image communicates content.
- Use empty `alt=""` when the image is purely decorative.

## Status Tracking

Mark each asset as it is completed:

- [ ] Concept approved
- [ ] Image generated or photographed
- [ ] Cropped for desktop
- [ ] Cropped for mobile
- [ ] Converted to WebP
- [ ] Compressed
- [ ] Added to HTML/CSS
- [ ] Verified on mobile
- [ ] Verified on desktop
