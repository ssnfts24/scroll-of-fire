# Home / Hero

## Purpose

Primary homepage hero artwork and responsive hero variants.

## Public Path

```text
/assets/img/home/hero/
```

## Planned Assets

- `home-codex-living-system.webp`
- `home-codex-living-system-mobile.webp`
- `home-codex-living-system-poster.webp`

## Rules

- Desktop target: 1920×1200 or larger.
- Mobile target: 1080×1350 with the central subject protected.
- Poster may be used as a loading fallback or social preview source.

## Naming Standard

Use lowercase kebab-case:

```text
section-purpose-variant.webp
```

Examples:

```text
home-gate-13-moons.webp
home-gate-13-moons-mobile.webp
home-gate-13-moons-poster.webp
```

## Export Standard

- Primary photographic or cinematic format: `.webp`
- Interface symbols and simple line art: `.svg`
- Transparent raster assets when necessary: `.png`
- Keep source or editable project files outside the public `docs/assets/` directory.
- Add `width` and `height` attributes in HTML to reduce layout shift.
- Use meaningful `alt` text when the image communicates content.
- Use empty `alt=""` when the image is purely decorative.

## Status Tracking

Mark each asset as it is completed:

- [ ] Concept approved
- [ ] Image generated or photographed
- [ ] Cropped for desktop
- [ ] Cropped for mobile
- [ ] Converted to WebP
- [ ] Compressed
- [ ] Added to HTML/CSS
- [ ] Verified on mobile
- [ ] Verified on desktop
