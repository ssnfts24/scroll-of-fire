# Home / Social

## Purpose

Homepage sharing cards and promotional social media crops.

## Public Path

```text
/assets/img/home/social/
```

## Planned Assets

- `home-social-og.webp`
- `home-social-facebook.webp`
- `home-social-square.webp`
- `home-social-story.webp`

## Rules

- Open Graph target: 1200×630.
- Square target: 1080×1080.
- Story target: 1080×1920.
- Text may be added only in social-specific exports.

## Naming Standard

Use lowercase kebab-case:

```text
section-purpose-variant.webp
```

Examples:

```text
home-gate-13-moons.webp
home-gate-13-moons-mobile.webp
home-gate-13-moons-poster.webp
```

## Export Standard

- Primary photographic or cinematic format: `.webp`
- Interface symbols and simple line art: `.svg`
- Transparent raster assets when necessary: `.png`
- Keep source or editable project files outside the public `docs/assets/` directory.
- Add `width` and `height` attributes in HTML to reduce layout shift.
- Use meaningful `alt` text when the image communicates content.
- Use empty `alt=""` when the image is purely decorative.

## Status Tracking

Mark each asset as it is completed:

- [ ] Concept approved
- [ ] Image generated or photographed
- [ ] Cropped for desktop
- [ ] Cropped for mobile
- [ ] Converted to WebP
- [ ] Compressed
- [ ] Added to HTML/CSS
- [ ] Verified on mobile
- [ ] Verified on desktop
