# Home

## Purpose

Homepage-only visual assets and gateway imagery.

## Public Path

```text
/assets/img/home/
```

## Planned Assets

- `home-codex-living-system.webp`
- `home-breath-field-poster.webp`
- `home-living-framework-equation.webp`
- `home-daily-return.webp`
- `home-core-gates.webp`

## Rules

- Use these assets only on the main Codex of Reality homepage.
- Keep text, buttons, and labels in HTML rather than baking them into images.
- Preserve open negative space for responsive text overlays.

## Naming Standard

Use lowercase kebab-case:

```text
section-purpose-variant.webp
```

Examples:

```text
home-gate-13-moons.webp
home-gate-13-moons-mobile.webp
home-gate-13-moons-poster.webp
```

## Export Standard

- Primary photographic or cinematic format: `.webp`
- Interface symbols and simple line art: `.svg`
- Transparent raster assets when necessary: `.png`
- Keep source or editable project files outside the public `docs/assets/` directory.
- Add `width` and `height` attributes in HTML to reduce layout shift.
- Use meaningful `alt` text when the image communicates content.
- Use empty `alt=""` when the image is purely decorative.

## Status Tracking

Mark each asset as it is completed:

- [ ] Concept approved
- [ ] Image generated or photographed
- [ ] Cropped for desktop
- [ ] Cropped for mobile
- [ ] Converted to WebP
- [ ] Compressed
- [ ] Added to HTML/CSS
- [ ] Verified on mobile
- [ ] Verified on desktop
