# Home / Posters

## Purpose

Static fallback images for animated, canvas, or interactive homepage features.

## Public Path

```text
/assets/img/home/posters/
```

## Planned Assets

- `home-poster-breath-field.webp`
- `home-poster-frequency-field.webp`
- `home-poster-living-network.webp`

## Rules

- Use when JavaScript is disabled, while animations load, or for reduced-motion mode.
- Poster imagery should closely match the first frame of the interactive element.

## Naming Standard

Use lowercase kebab-case:

```text
section-purpose-variant.webp
```

Examples:

```text
home-gate-13-moons.webp
home-gate-13-moons-mobile.webp
home-gate-13-moons-poster.webp
```

## Export Standard

- Primary photographic or cinematic format: `.webp`
- Interface symbols and simple line art: `.svg`
- Transparent raster assets when necessary: `.png`
- Keep source or editable project files outside the public `docs/assets/` directory.
- Add `width` and `height` attributes in HTML to reduce layout shift.
- Use meaningful `alt` text when the image communicates content.
- Use empty `alt=""` when the image is purely decorative.

## Status Tracking

Mark each asset as it is completed:

- [ ] Concept approved
- [ ] Image generated or photographed
- [ ] Cropped for desktop
- [ ] Cropped for mobile
- [ ] Converted to WebP
- [ ] Compressed
- [ ] Added to HTML/CSS
- [ ] Verified on mobile
- [ ] Verified on desktop
