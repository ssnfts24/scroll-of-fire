# Home / Sections

## Purpose

Supporting visuals for major homepage explanation sections.

## Public Path

```text
/assets/img/home/sections/
```

## Planned Assets

- `home-section-what-this-is.webp`
- `home-section-daily-return.webp`
- `home-section-living-framework.webp`
- `home-section-manifest-practice.webp`
- `home-section-caravan-path.webp`

## Rules

- These explain processes rather than act as navigation thumbnails.
- Use wide landscape compositions where the section spans the page.
- Keep visual complexity lower than the hero.

## Naming Standard

Use lowercase kebab-case:

```text
section-purpose-variant.webp
```

Examples:

```text
home-gate-13-moons.webp
home-gate-13-moons-mobile.webp
home-gate-13-moons-poster.webp
```

## Export Standard

- Primary photographic or cinematic format: `.webp`
- Interface symbols and simple line art: `.svg`
- Transparent raster assets when necessary: `.png`
- Keep source or editable project files outside the public `docs/assets/` directory.
- Add `width` and `height` attributes in HTML to reduce layout shift.
- Use meaningful `alt` text when the image communicates content.
- Use empty `alt=""` when the image is purely decorative.

## Status Tracking

Mark each asset as it is completed:

- [ ] Concept approved
- [ ] Image generated or photographed
- [ ] Cropped for desktop
- [ ] Cropped for mobile
- [ ] Converted to WebP
- [ ] Compressed
- [ ] Added to HTML/CSS
- [ ] Verified on mobile
- [ ] Verified on desktop
