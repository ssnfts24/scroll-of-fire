# Codex of Reality — Homepage Image Pathways

This package defines the image folder structure for the Codex of Reality homepage and places a `README.md` inside every planned directory.

## Root Path

```text
docs/assets/img/
```

## Pathway Map

```text
docs/
└── assets/
    └── img/
        ├── home/
        │   ├── hero/
        │   ├── gates/
        │   ├── sections/
        │   ├── backgrounds/
        │   ├── posters/
        │   └── social/
        └── shared/
            ├── icons/
            └── textures/
```

## Routing Logic

### `home/`

Use for images that belong only to the homepage.

### `home/hero/`

Use for the single primary visual that introduces the entire Codex.

### `home/gates/`

Use for clickable visual pathways into major systems such as 13 Moons, Covenant Caravan, Frequency Governance, Witness Ledger, Artifacts, Oracle, and Theory.

### `home/sections/`

Use for explanatory images placed inside major homepage sections.

### `home/backgrounds/`

Use for low-contrast ambient section backgrounds and textures.

### `home/posters/`

Use for static fallbacks for animations, canvases, interactive fields, and reduced-motion mode.

### `home/social/`

Use for Open Graph images and social promotion crops based on the homepage.

### `shared/`

Use only when the same asset appears across multiple pages.

### `shared/icons/`

Use for lightweight navigation symbols and interface icons.

### `shared/textures/`

Use for reusable material or atmosphere layers.

## Decision Rule

Before adding an image, ask:

1. Is it used only on the homepage?
   - Put it in `home/`.
2. Does it open a major system?
   - Put it in `home/gates/`.
3. Is it the main hero?
   - Put it in `home/hero/`.
4. Does it explain a homepage section?
   - Put it in `home/sections/`.
5. Is it a fallback for animation?
   - Put it in `home/posters/`.
6. Is it used across multiple pages?
   - Put it in `shared/`.

## Recommended Homepage Loading Order

1. Hero poster or hero image
2. Above-the-fold gateway images
3. Remaining gateway images
4. Section explanation images
5. Background textures
6. Social assets are never loaded into the page itself

## HTML Path Examples

```html
<img
  src="/assets/img/home/hero/home-codex-living-system.webp"
  alt="The Codex of Reality shown as an interconnected living system."
  width="1920"
  height="1200"
  loading="eager"
  fetchpriority="high"
>

<img
  src="/assets/img/home/gates/home-gate-13-moons.webp"
  alt="Enter the Remnant 13 Moons calendar."
  width="1200"
  height="1200"
  loading="lazy"
>
```

## CSS Path Example

```css
.home-frequency-section {
  background-image:
    linear-gradient(rgba(5, 7, 13, 0.72), rgba(5, 7, 13, 0.94)),
    url("/assets/img/home/backgrounds/home-bg-celestial-grid.webp");
}
```

## Production Sequence

### Phase 1 — Identity

- Homepage living-system hero
- Mobile hero crop
- Open Graph image

### Phase 2 — Primary Gateways

- 13 Moons
- Covenant Caravan
- Frequency Governance
- Witness Ledger
- Artifact Registry

### Phase 3 — Extended Gateways

- Genesis Oracle
- Theory / Canon

### Phase 4 — Explanatory Visuals

- Daily Return
- Living Framework equation
- Manifest practice
- Caravan five-stage pathway

### Phase 5 — Ambient and Technical Assets

- Background textures
- Animation posters
- Reduced-motion fallbacks
- Social crops

## Core Visual Standard

Every image should feel like part of the same world:

- Deep navy and near-black foundation
- Warm gold and copper structure
- Cyan living signal or field energy
- Authentic stone, water, fire, air, stars, and handcrafted material
- One clear visual purpose per image
- No collage layouts unless specifically designed as a social promotional image
- No important text baked into normal website images
